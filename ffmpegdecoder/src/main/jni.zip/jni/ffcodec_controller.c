#include <string.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>

#include <android/log.h>

#define LOG_TAG "MediaPlayer-JNI"

#define ALOGE(...) \
    __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__);
#define ALOGW(...) \
    __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__);
#define ALOGD(...) \
    __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__);
#define ALOGV(...) \
    __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__);
#define ALOGI(...) \
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__);



#include "include/libswscale/swscale.h"
#include "include/libavcodec/avcodec.h"
#include "include/libavformat/avformat.h"
#include "include/libavfilter/avfilter.h"
#include "include/libavformat/avformat.h"
#include "include/libavcodec/avcodec.h"
#include "include/libavutil/frame.h"

AVFormatContext *pFormatCtx;
AVCodecContext *pCodecCtxOrig;
AVCodecContext *pCodecCtx;
AVCodec *pCodec;
AVFrame *pFrame;
AVFrame *pFrameInYUV;
AVPacket packet;

FILE* save_file;
FILE* fp_yuv;
int frame_count = 0;
char out_file_name[] = "/mnt/sdcard/ffout.yuv";
int got_picture;
uint8_t *out_buffer;
uint8_t *decoded_buffer;
struct SwsContext *img_convert_ctx;
int y_size;

clock_t time_start, time_finish;
clock_t time_start_all, time_finish_all;
clock_t time_s1, time_s2;
long time_duration = 0;

/*
 const uint8_t  priv_data[] = {
 0x00 ,0x00 ,0x00 ,0x01 ,0x09 ,0x10 ,0x00 ,0x00,
 0x00 ,0x01 ,0x67 ,0x4D ,0x40 ,0x1F ,0x9A ,0x66 ,
 0x02 ,0x80 ,0x2D ,0xFF ,0x80 ,0xB7 ,0x01 ,0x01 ,
 0x01 ,0x40 ,0x00 ,0x00 ,0xFA ,0x00 ,0x00 ,0x3A ,
 0x98 ,0x3A ,0x18 ,0x00 ,0xF4 ,0x20 ,0x00 ,0x0D ,
 0x59 ,0xFA ,0xEF ,0x2E ,0x34 ,0x30 ,0x01 ,0xE8 ,
 0x40 ,0x00 ,0x1A ,0xB3 ,0xF5 ,0xDE ,0x5C ,0x28 ,
 0x00 ,0x00 ,0x00 ,0x01 ,0x68 ,0xEE ,0x38 ,0x80
 };
 */

static int decode_h264_to_yuv(const char src[], const char dest[]);

static int save_to_file(void* buf, int unit, int length, FILE* fp) {
	if (!fp) {
		fp = fopen(out_file_name, "ab+");
		if (fp == NULL) {
			ALOGE("open save file error!");
			return -1;
		}
	}

	fwrite(buf, unit, length, fp);
	return 0;
}


static int init_by_file(const char src[]) {
	int videoStream = -1;
	int i;
	av_register_all();

	if (avformat_open_input(&pFormatCtx, src, NULL, NULL) != 0) {
		ALOGE(" Couldn't open file");
		return -1; // Couldn't open file
	}

	if (avformat_find_stream_info(pFormatCtx, NULL) < 0) {
		ALOGE("Couldn't find stream information");
		return -1; // Couldn't find stream information
	}

	// Find the first video stream
	for (i = 0; i < pFormatCtx->nb_streams; i++)
		if (pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
			videoStream = i;
			break;
		}

	if (videoStream == -1)
		return -1; // Didn't find a video stream

	// Get a pointer to the codec context for the video stream
	pCodecCtxOrig = pFormatCtx->streams[videoStream]->codec;

	pCodec = avcodec_find_decoder(pCodecCtxOrig->codec_id);	// Find the decoder for the video stream
	if (pCodec == NULL) {
		fprintf(stderr, "Unsupported codec!\n");
		return -1; // Codec not found
	}

	// Copy context
	pCodecCtx = avcodec_alloc_context3(pCodec);
	if (avcodec_copy_context(pCodecCtx, pCodecCtxOrig) != 0) {
		fprintf(stderr, "Couldn't copy codec context");
		return -1; // Error copying codec context
	}

	// Open codec
	if (avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
		return -1; // Could not open codec
	pCodecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
	// Allocate video frame
	pFrame = av_frame_alloc();

	// Allocate an AVFrame structure
	pFrameInYUV = av_frame_alloc();
	if (pFrameInYUV == NULL)
		return -1;

	out_buffer = (uint8_t *) av_malloc(
			avpicture_get_size(PIX_FMT_YUV420P, pCodecCtx->width,
							   pCodecCtx->height));
	avpicture_fill((AVPicture *) pFrame, out_buffer, PIX_FMT_YUV420P,
				   pCodecCtx->width, pCodecCtx->height);
	av_init_packet(&packet);

	/*	img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height,
	 pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height,
	 PIX_FMT_YUV420P, SWS_BICUBIC, NULL, NULL, NULL);*/

	/*	fp_yuv = fopen(dest, "wb+");
	 if (!fp_yuv) {
	 ALOGE("open file error");
	 return -1;
	 }*/

	i = 0;
	//time_start_all = clock();
	//av_read_frame(pFormatCtx, &packet);

	return 0;
}

static int init_val() {
	int videoStream, i;
	const char src[] = "/mnt/sdcard/hand.h264";
	fp_yuv = fopen("/mnt/sdcard/ffout2.yuv", "wb+");

	int result;
	av_register_all();

	pFormatCtx = avformat_alloc_context();
	if (!pFormatCtx) {
		ALOGE(" avformat_alloc_context() return error!");
		return -1; // Codec not found
	}

	pCodec = avcodec_find_decoder(AV_CODEC_ID_H264);
	if (!pCodec) {
		ALOGE(" avcodec_find_decoder(AV_CODEC_ID_H264) return error!");
		return -1; // Codec not found
	}

	pCodecCtx = avcodec_alloc_context3(pCodec);
	if (!pCodecCtx) {
		ALOGE(" avcodec_alloc_context3() return error!");
		return -1; // Codec not found
	}

	//pCodecCtx->extradata = (uint8_t *)av_malloc(sizeof(priv_data));
	//memcpy(pCodecCtx->extradata,&priv_data[0],sizeof(priv_data));
	//pCodecCtx->extradata_size = sizeof(priv_data);

	//use muti thread decode , it may delay (n-1)frame ,n is thread count
	pCodecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
	pCodec->capabilities |= AV_CODEC_CAP_FRAME_THREADS;
	pCodec->capabilities |= AV_CODEC_CAP_AUTO_THREADS;
	pCodecCtx->codec = pCodec;
	pCodecCtx->thread_count = 0;

	pCodecCtx->thread_type = FF_THREAD_FRAME;
	pCodecCtx->flags  &=(~AV_CODEC_FLAG_TRUNCATED);
	pCodecCtx->flags &= (~AV_CODEC_FLAG_LOW_DELAY);
	pCodecCtx->flags2 &= (~AV_CODEC_FLAG2_CHUNKS);
	pCodecCtx->delay = 4;

	result = avcodec_open2(pCodecCtx, pCodec, NULL);
	if (result < 0) {
		ALOGE("avcodec_open2 error!");
		return result;
	}

	/*
	 pCodecCtx->codec_id = AV_CODEC_ID_H264;
	 pCodecCtx->ticks_per_frame = 2;
	 pCodecCtx->frame_number = 1;
	 pCodecCtx->codec_type = AVMEDIA_TYPE_VIDEO;
	 pCodecCtx->bit_rate = 0;
	 pCodecCtx->time_base.den = 60; //֡��
	 pCodecCtx->time_base.num = 1;
	 pCodecCtx->width = 1280; //��Ƶ��
	 pCodecCtx->height = 720; //��Ƶ��
	 pCodecCtx->refs = 2;
	 pCodecCtx->sample_fmt = -1;
	 pCodecCtx->profile = FF_PROFILE_H264_MAIN;
	 pCodecCtx->level = 31;
	 pCodecCtx->slice_count = 0;
	 pCodecCtx->slices = 0;
	 pCodecCtx->channels = 0;

	 ALOGE("pFormatCtx->iformat->name:%s", pFormatCtx->iformat->name);
	 ALOGE("capabilities:%d", pCodec->capabilities);
	 ALOGE("capabilities:%d", pCodecCtx->active_thread_type);*/

	pFrame = av_frame_alloc();
	if (!pFrame) {
		ALOGE("av_frame_alloc() error!");
		return result;
	}

	out_buffer = (uint8_t *) av_malloc(
			avpicture_get_size(PIX_FMT_YUV420P, pCodecCtx->width,
							   pCodecCtx->height));
	avpicture_fill((AVPicture *) pFrame, out_buffer, PIX_FMT_YUV420P,
				   pCodecCtx->width, pCodecCtx->height);

	pCodecCtx->codec = pCodec;

	av_init_packet(&packet);
	return 0;
}

static jint oyyj_media_softcodec_ffcodecController_ffcodec_init_native(
		JNIEnv* env) {
	return init_val();
	//return init_by_file("/mnt/sdcard/hand.h264");
	//return decode_h264_to_yuv("/mnt/sdcard/hand.h264","/mnt/sdcard/ffout.yuv");
}

static jint oyyj_media_softcodec_ffcodecController_ffcodec_decode_h264_to_yuv(JNIEnv *env, jobject thiz,jstring srcFilePath,jstring outFilepath)
{
	char * h264Str = (*env)->GetStringUTFChars(env,srcFilePath,NULL);
	char * mp4Str = (*env)->GetStringUTFChars(env,outFilepath,NULL);


	int retCode = 0;
	retCode = init_by_file(h264Str);
	retCode = decode_h264_to_yuv(h264Str,mp4Str);

	(*env)->ReleaseStringUTFChars(env,srcFilePath,h264Str);
	(*env)->ReleaseStringUTFChars(env,outFilepath,mp4Str);

	return retCode;
}

static jstring oyyj_media_softcodec_ffcodecController_ffcodec_get_codocinfo(
		JNIEnv* env) {

	char info[40000] = { 0 };
	ALOGE("native init ok!");

	AVCodec *c_temp = av_codec_next(NULL);

	while (c_temp != NULL ) {
		if (c_temp->decode != NULL) {
			sprintf(info, "%s[Dec]", info);
		} else {
			sprintf(info, "%s[Enc]", info);
		}
		switch (c_temp->type) {
			case AVMEDIA_TYPE_VIDEO:
				sprintf(info, "%s[Video]", info);
				break;
			case AVMEDIA_TYPE_AUDIO:
				sprintf(info, "%s[Audio]", info);
				break;
			default:
				sprintf(info, "%s[Other]", info);
				break;
		}
		sprintf(info, "%s[%10s]\n", info, c_temp->name);

		c_temp = c_temp->next;
	}
	ALOGE("%s", info);
	return (*env)->NewStringUTF(env, info);
}


//需要 av_malloc 和 av_free，比较耗资源
static jint oyyj_media_softcodec_ffcodecController_ffcodec_native_decode_frame(
		JNIEnv *env, jobject thiz, jbyteArray preDecodeData, jint offsetInBytes,
		jint sizeInBytes, jbyteArray resultData) {
	int ret = 0;
	jbyte *buf_in_addr;
	jbyte *buf_out_addr;
	jint *size_addr;

	buf_in_addr = (*env)->GetByteArrayElements(env, preDecodeData, 0);
	buf_out_addr = (*env)->GetByteArrayElements(env, resultData, 0);

	if (!buf_in_addr || !buf_out_addr) {
		(*env)->ReleaseByteArrayElements(env, preDecodeData, buf_in_addr, 0);
		ALOGE("GetByteArrayElements error!");
		(*env)->ReleaseByteArrayElements(env, resultData, buf_out_addr, 0);
		return -1;
	}
	uint8_t * buffer_with_padding = (uint8_t*) av_malloc(
			sizeInBytes + AV_INPUT_BUFFER_PADDING_SIZE);
	memcpy(buffer_with_padding, (uint8_t*) buf_in_addr, sizeInBytes);

	packet.data = buffer_with_padding;
	packet.size = sizeInBytes;
	/*	packet.data =buf_in_addr;
	 packet.size = sizeInBytes;*/

	//ALOGE("active_thread_type:%d,thread_type:%d,delay:%d,thread counts:%d",pCodecCtx->active_thread_type, pCodecCtx->thread_type,
	//		pCodecCtx->delay, pCodecCtx->thread_count);
	time_start = clock();
	ret = avcodec_decode_video2(pCodecCtx, pFrame, &got_picture, &packet);

	//ALOGE("packet size:%d", sizeInBytes);
	if (got_picture) {

		//ALOGE("get picture! size:%d", ret);
		time_finish = clock();
		time_duration = (time_finish - time_start) / 1000;
		time_start = clock();
		y_size = pCodecCtx->width * pCodecCtx->height;

		switch (pFrame->pict_type) {
			case AV_PICTURE_TYPE_I:
				ALOGI("I frame")
				;
				break;
			case AV_PICTURE_TYPE_P:
				ALOGI("P frame")
				;
				break;
			case AV_PICTURE_TYPE_B:
				ALOGI("B frame")
				;
				break;
			default:
				ALOGI("Other frame")
				;
				break;
		}
		frame_count++;
		ret = y_size * 3 / 2;

		memcpy((uint8_t *) buf_out_addr, pFrame->data[0], y_size);
		memcpy((uint8_t *) buf_out_addr + y_size, pFrame->data[1], y_size / 4);
		memcpy((uint8_t *) buf_out_addr + y_size + y_size / 4, pFrame->data[2],
			   y_size / 4);
		time_finish = clock();
	} else {
		//	ALOGE("decode nothing!");
		ret = -1;
	}

	(*env)->ReleaseByteArrayElements(env, preDecodeData, buf_in_addr, 0);
	(*env)->ReleaseByteArrayElements(env, resultData, buf_out_addr, 0);
	av_free(buffer_with_padding);
	ALOGI(" cost%ld ms, save cost:%ld", time_duration,(clock() - time_start) / 1000);

	return ret;
}


static jint decode_internal(jbyte * buf_in_addr,jint length,jbyte* buf_out_addr)
{
	int frameFinished;
	int ret;

	packet.data = buf_in_addr;
	packet.size = length;
	ret = avcodec_decode_video2(pCodecCtx,pFrame,&frameFinished,&packet);

	if(frameFinished)
	{
		ALOGE("get picture! size:%d", ret);
		time_finish = clock();
		time_duration = (time_finish - time_start) / 1000;
		time_start = clock();


		y_size = pCodecCtx->width * pCodecCtx->height;

		switch (pFrame->pict_type) {
			case AV_PICTURE_TYPE_I:
				ALOGI("I frame")
				;
				break;
			case AV_PICTURE_TYPE_P:
				ALOGI("P frame")
				;
				break;
			case AV_PICTURE_TYPE_B:
				ALOGI("B frame")
				;
				break;
			default:
				ALOGI("Other frame")
				;
				break;
		}
		frame_count++;
		ret = y_size * 3 / 2;

		memcpy((uint8_t *) buf_out_addr, pFrame->data[0], y_size);
		memcpy((uint8_t *) buf_out_addr + y_size, pFrame->data[1], y_size / 4);
		memcpy((uint8_t *) buf_out_addr + y_size + y_size / 4, pFrame->data[2],
			   y_size / 4);
		time_finish = clock();
	}else
	{
		return -1;
	}

	return ret;
}

static jint oyyj_media_softcodec_ffcodecController_ffcodec_native_decode_h264_frame(JNIEnv *env, jobject thiz, jbyteArray preDecodeData,jint length,jbyteArray resultData)
{
	int ret = 0;
	jbyte *buf_in_addr;
	jbyte *buf_out_addr;
	jint *size_addr;
	int frameFinished;

	buf_in_addr = (*env)->GetByteArrayElements(env, preDecodeData, 0);
	buf_out_addr = (*env)->GetByteArrayElements(env, resultData, 0);

	ret = decode_internal(buf_in_addr,length,buf_out_addr);

	(*env)->ReleaseByteArrayElements(env, preDecodeData, buf_in_addr, 0);
	(*env)->ReleaseByteArrayElements(env, resultData, buf_out_addr, 0);

	return ret;
}



static int decode_h264_to_yuv(const char src[], const char dest[]) {
	// Initalizing these to NULL prevents segfaults!
	AVFormatContext *pFormatCtx = NULL;
	int i, videoStream;
	AVCodecContext *pCodecCtxOrig = NULL;
	AVCodecContext *pCodecCtx = NULL;
	AVCodec *pCodec = NULL;
	AVFrame *pFrame = NULL;
	AVFrame *pFrameInYUV = NULL;
	AVPacket packet;
	int frameFinished;
	int frame_cnt;
	struct SwsContext *sws_ctx = NULL;
	uint8_t *out_buffer;
	FILE *fp_yuv;

	av_register_all();

	if (avformat_open_input(&pFormatCtx, src, NULL, NULL) != 0) {
		ALOGE(" Couldn't open file");
		return -1; // Couldn't open file
	}

	if (avformat_find_stream_info(pFormatCtx, NULL) < 0) {
		ALOGE("Couldn't find stream information");
		return -1; // Couldn't find stream information
	}

	// Find the first video stream
	videoStream = -1;
	for (i = 0; i < pFormatCtx->nb_streams; i++)
		if (pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
			videoStream = i;
			break;
		}

	if (videoStream == -1)
		return -1; // Didn't find a video stream

	pCodecCtxOrig = pFormatCtx->streams[videoStream]->codec; // Get a pointer to the codec context for the video stream

	pCodec = avcodec_find_decoder(pCodecCtxOrig->codec_id);	// Find the decoder for the video stream
	if (pCodec == NULL) {
		fprintf(stderr, "Unsupported codec!\n");
		return -1; // Codec not found
	}

	// Copy context
	pCodecCtx = avcodec_alloc_context3(pCodec);
	if (avcodec_copy_context(pCodecCtx, pCodecCtxOrig) != 0) {
		fprintf(stderr, "Couldn't copy codec context");
		return -1; // Error copying codec context
	}

	// Open codec
	if (avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
		return -1; // Could not open codec
	pCodecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
	// Allocate video frame
	pFrame = av_frame_alloc();

	// Allocate an AVFrame structure
	pFrameInYUV = av_frame_alloc();
	if (pFrameInYUV == NULL)
		return -1;

	out_buffer = (uint8_t *) av_malloc(
			avpicture_get_size(PIX_FMT_YUV420P, pCodecCtx->width,
							   pCodecCtx->height));
	avpicture_fill((AVPicture *) pFrameInYUV, out_buffer, PIX_FMT_YUV420P,
				   pCodecCtx->width, pCodecCtx->height);
	av_init_packet(&packet);

	/*	img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height,
	 pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height,
	 PIX_FMT_YUV420P, SWS_BICUBIC, NULL, NULL, NULL);*/

	fp_yuv = fopen(dest, "wb+");
	if (!fp_yuv) {
		ALOGE("open file error");
		return -1;
	}

	i = 0;
	time_start_all = clock();
	av_read_frame(pFormatCtx, &packet);
	while (av_read_frame(pFormatCtx, &packet) >= 0) {
		// Is this a packet from the video stream?

		//debug only

		if (packet.stream_index == videoStream) {
			time_start = clock();
			ALOGE(
					"active_thread_type:%d,thread_type:%d,delay:%d,thread count:%d",
					pCodecCtx->active_thread_type, pCodecCtx->thread_type,
					pCodecCtx->delay, pCodecCtx->thread_count);

			frameFinished = decode_internal(packet.data,packet.size,pFrame->data);
			//avcodec_decode_video2(pCodecCtx, pFrame, &frameFinished, &packet); // Decode video frame

			// Did we get a video frame?
			if (frameFinished) {
				time_finish = clock();
				time_duration = (time_finish - time_start) / 1000;
				time_s1 = clock();
				// sws_scale(img_convert_ctx, (const uint8_t* const*)pFrame->data, pFrame->linesize, 0, pCodecCtx->height,
				//   pFrameInYUV->data, pFrameInYUV->linesize);

				y_size = pCodecCtx->width * pCodecCtx->height;
				time_s2 = clock();
				fwrite(pFrame->data[0], 1, y_size, fp_yuv);    //Y
				fwrite(pFrame->data[1], 1, y_size / 4, fp_yuv);  //U
				fwrite(pFrame->data[2], 1, y_size / 4, fp_yuv);  //V

				//Output info
				char pictype_str[10] = { 0 };
				switch (pFrame->pict_type) {
					case AV_PICTURE_TYPE_I:
						sprintf(pictype_str, "I");
						break;
					case AV_PICTURE_TYPE_P:
						sprintf(pictype_str, "P");
						break;
					case AV_PICTURE_TYPE_B:
						sprintf(pictype_str, "B");
						break;
					default:
						sprintf(pictype_str, "Other");
						break;
				}
				ALOGE(
						"Frame Index: %d. Type:%s. cost%ld ms, scale cost:%ld, save cost:%ld",
						frame_cnt, pictype_str, time_duration,
						(time_s2 - time_s1) / 1000, (clock() - time_s2) / 1000);
				frame_cnt++;
			}
		}

		// Free the packet that was allocated by av_read_frame
		av_free_packet(&packet);

	}
	time_finish_all = clock();
	ALOGE("total cost:%ld s",
		  (long )(time_finish_all - time_start_all) / 1000 / 1000);

	// Free the RGB image
	av_free(out_buffer);
	av_frame_free(&pFrameInYUV);

	// Free the YUV frame
	av_frame_free(&pFrame);

	// Close the codecs
	avcodec_close(pCodecCtx);
	avcodec_close(pCodecCtxOrig);

	// Close the video file
	avformat_close_input(&pFormatCtx);

	return 0;
}

static jint oyyj_media_softcodec_ffcodecController_ffcodec_native_initH264Decoder(JNIEnv *env, jobject thiz, jint width ,jint height)
{
	ALOGE("Decode_init");

	AVCodec * pCodec=NULL;
	avcodec_register_all();

	av_init_packet(&packet);
	pCodec=avcodec_find_decoder(CODEC_ID_H264);
	if(NULL!=pCodec)
	{
		pCodecCtx=avcodec_alloc_context3(pCodec);
		if(avcodec_open2(pCodecCtx,pCodec,NULL)>=0)
		{
			pCodecCtx->height = height;
			pCodecCtx->width = width;

			pFrame=avcodec_alloc_frame();
		}

		return  decode_h264_to_yuv("/mnt/sdcard/hand.h264","/mnt/sdcard/ffout.yuv");
	}
	else
		return 0;
}


static jint oyyj_media_softcodec_ffcodecController_ffcodec_native_close() {
	//av_free(out_buffer);
	av_frame_free(&pFrame);
	avcodec_close(pCodecCtx);
	avformat_close_input(&pFormatCtx);
	return 0;
}

static const JNINativeMethod method_table[] =
		{
//				{ "ffcodec_init_native", "()I",
//						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_init_native },
//
//				{ "ffcodec_native_decode_frame", "([BII[B)I",
//						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_native_decode_frame },
//
//				{ "ffcodec_get_codocinfo", "()Ljava/lang/String;",
//						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_get_codocinfo },
//
//				{ "ffcodec_native_close", "()I",
//						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_native_close },

				{ "ffcodec_deinit_h264_decoder", "()I",
						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_native_close },

				{ "ffcodec_init_h264_decoder", "(II)I",
						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_native_initH264Decoder },

				{ "ffcodec_decode_h264_frame", "([BI[B)I",
						(void*) oyyj_media_softcodec_ffcodecController_ffcodec_native_decode_h264_frame },
		};

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	JNIEnv* env = NULL;
	jint result = -1;

	if ((*vm)->GetEnv(vm, (void**) &env, JNI_VERSION_1_4) != JNI_OK)
		return -1;

	jclass clazz;
	static const char* const kClassName =
			"oyyj/media/softcodec/FFCodecController";

	clazz = (*env)->FindClass(env, kClassName);

	if (clazz == NULL) {
		ALOGE("cannot get class:%s\n", kClassName);
		return -1;
	}

	if ((*env)->RegisterNatives(env, clazz, method_table,
								sizeof(method_table) / sizeof(method_table[0])) != JNI_OK)
	{
		ALOGE("register native method failed!\n");
		return -1;
	}

	return JNI_VERSION_1_4;
}

